#ifndef SHELL_IOS_H_
#define SHELL_IOS_H_

char* ios_get_home(void);
char* ios_get_temp(void);
char* ios_get_data(void);
char* ios_get_cache(void);

#endif
