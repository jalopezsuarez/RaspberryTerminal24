
int winpr_dummy()
{
	return 0;
}
