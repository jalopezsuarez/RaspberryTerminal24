
#include <winpr/crt.h>
#include <winpr/pool.h>

int TestPoolIO(int argc, char* argv[])
{
	return 0;
}
