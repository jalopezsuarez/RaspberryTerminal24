
#include <stdio.h>
#include <winpr/crt.h>
#include <winpr/path.h>
#include <winpr/tchar.h>
#include <winpr/winpr.h>

int TestPathCchCanonicalizeEx(int argc, char* argv[])
{
	printf("Warning: %s is not implemented!\n", __FUNCTION__);
	return 0;
}
