
#include <stdio.h>
#include <winpr/io.h>
#include <winpr/crt.h>
#include <winpr/windows.h>

int TestIoGetOverlappedResult(int argc, char* argv[])
{
	return 0;
}
