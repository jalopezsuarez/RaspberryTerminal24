# Manual Testing Environments

Choose one of the directories (which are named after their scenario) and run the **run.sh**

## Example
```shell
cd environments/vncserver
sh run.sh
```

This will run a docker container that provides the expected use case.

