## Release type or title

## List of changes

<!-- Taken from the changelog -->

## Developer checklist

- [ ] Did you change the version in CMakeLists.txt, data/desktop/org.remmina.Remmina.appdata.xml, po/remmina.pot and Doxyfile ?
- [ ] Did you update the CHANGELOG.md file ?
- [ ] Did you update the authors list in data/ui/remmina_about.glade ?
- [ ] Did you update the flatpak files with any changes?

/cc @bkohler @larchunix @kathenas @jweberhofer @tukusejssirs @kingu @ToolsDevler @raghavgururajan

/label ~RELEASE
