# Remmina SSH terminal Color Scheme

See https://github.com/mbadolato/iTerm2-Color-Schemes.

Screenshots are at the link https://github.com/mbadolato/iTerm2-Color-Schemes/blob/master/screenshots/README.md
