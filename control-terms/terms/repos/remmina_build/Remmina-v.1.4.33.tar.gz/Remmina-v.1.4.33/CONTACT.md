Welcome to the Remmina community

Accept and offer criticism constructively.
Let anyone have the privacy they desire.

Settle differences within these boundaries.

Finding yourself unable to do so, e-mail admin@remmina.org,
answered by the project team.

We are in an IRC room on libera.chat, in the #remmina channel, you can also use a [web client](https://web.libera.chat/?nick=remminer|?#remmina).
